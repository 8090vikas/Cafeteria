
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Iterator;
import jakarta.HttpServlet;
import javax.servlet.WebServlet;

@WebServlet(
   name = "AddToCartServlet",
   urlPatterns = {"add-to-cart"}
)
public class AddToCartServlet extends HttpServlet {
   private static final long serialVersionUID = 1L;

   public AddToCartServlet() {
   }

   protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      response.setContentType("text/html;charset=UTF-8");
      Throwable var3 = null;
      Object var4 = null;

      try {
         PrintWriter out = response.getWriter();

         try {
            ArrayList<Cart> cartList = new ArrayList();
            int id = Integer.parseInt(request.getParameter("id"));
            Cart cm = new Cart();
            cm.setId(id);
            cm.setQuantity(1);
            HttpSession session = request.getSession();
            ArrayList<Cart> cart_list = (ArrayList)session.getAttribute("cart-list");
            if (cart_list == null) {
               cartList.add(cm);
               session.setAttribute("cart-list", cartList);
               response.sendRedirect("index.jsp");
            } else {
               boolean exist = false;
               Iterator var13 = cart_list.iterator();

               while(var13.hasNext()) {
                  Cart c = (Cart)var13.next();
                  if (c.getId() == id) {
                     exist = true;
                     out.println("<h3 style='color:crimson; text-align: center'>Item Already in Cart. <a href='cart.jsp'>GO to Cart Page</a></h3>");
                  }
               }

               if (!exist) {
                  cart_list.add(cm);
                  response.sendRedirect("index.jsp");
               }
            }
         } finally {
            if (out != null) {
               out.close();
            }

         }

      } catch (Throwable var19) {
         if (var3 == null) {
            var3 = var19;
         } else if (var3 != var19) {
            var3.addSuppressed(var19);
         }

         throw var3;
      }
   }
}
